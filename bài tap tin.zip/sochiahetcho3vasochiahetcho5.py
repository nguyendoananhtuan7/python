n = 300
wc3v5 = 0
k=0
while k<n:
    if k%3==0 and k%5==0:
        wc3v5 = wc3v5 + 1
    k = k + 1
print(wc3v5)    
        
    
