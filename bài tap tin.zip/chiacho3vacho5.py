fc3v5 = 0
n = 100
for i in range(n):
    if i%3==0 and i%5==0:
        fc3v5 = fc3v5 + 1
print(fc3v5)

