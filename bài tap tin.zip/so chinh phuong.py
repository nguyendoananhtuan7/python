x = int(input("nhap vao so nguyen x: "))

scp = 1
for i in range(1,x+1):
 if int(i**0.5)**2 == i:
     scp *= i
print("tích các số chính phương là: ",Sscp)    
